var bg = chrome.extension.getBackgroundPage(),audio = bg.audio;
var songList = {};
function showSong(songListHead,out,S){
	if(songListHead.type == 'songNode'){
		appendSong(songListHead.name,out,S);
	}
	if(songListHead.nxt){
		showSong(songListHead.nxt,out,S);
	}
}
function appendSong(name,out,S){
	var DOM = S.DOM,Event = S.Event,
		newSong = DOM.create('<li class="showSongListLoop"><span class="songName">'+name+'</span></li>');
		newSong.name = name;
	var moveBlock = DOM.create('<div class="moveblock" title="Drag to move"></div>'),
		delBlock = DOM.create('<div class="delblock" title="Delete"></div>'),
		downBlock = DOM.create('<div class="downblock" title="Download"></div>');
	DOM.append(moveBlock,newSong);
	DOM.append(delBlock,newSong);
	DOM.append(downBlock,newSong);
	DOM.append(newSong,out);
	DOM.scrollIntoView(newSong);
	songList[name] = newSong;
	//=============songList move==================================================
	var moveflag = false,
		preOfstTop,preClientY;
	Event.on(moveBlock,'mousedown',function(e){
		moveflag = true;
		preClientY = e.clientY;
		preOfstTop = DOM.offset(newSong).top;
		DOM.addClass(newSong,'move');
	});
	Event.on(document,'mousemove',function(e){
		if(moveflag){
			e.preventDefault();
			DOM.offset(newSong,{
				top:preOfstTop + e.clientY - preClientY,
				left:DOM.offset(newSong).left
			});
			var songListLis = DOM.siblings(newSong,'.showSongListLoop');
			for(var i=0;i<songListLis.length;i++){
				if(DOM.offset(songListLis[i]).top>DOM.offset(newSong).top){
					bg.moveList(newSong.name,songListLis[i].name);
					DOM.insertBefore(newSong,songListLis[i]);
					
					break;
				}
			}
			if(i == songListLis.length){
				DOM.append(newSong,DOM.parent(newSong));
			}
		}
	});
	Event.on(document,'mouseup',function(){
		if(moveflag){
			moveflag = false;	
			DOM.css(newSong,'top','0px');
			setTimeout(function(){DOM.removeClass(newSong,'move');},100);
		}
	});
	//================songList del========================================
	Event.on(delBlock,'click',function(){
		bg.delSong(name);
		S.one(newSong).fadeOut();
		setTimeout(function(){DOM.remove(newSong);},1000);
	});
	//================downLoad============================================
	Event.on(downBlock,'click',function(){
		var list = bg.songList[name].content;
		if(list.length){
			showDownload(name,list,S);
		}
	});
	//================dblclick to play====================================
	Event.on(newSong,'dblclick',function(){
		bg.gotoPlay(name);
	});
}
function showNowPlay(nowPlaySong,songListUI,S){
	if(!nowPlaySong) return false;
	var DOM = S.DOM,Event = S.Event;
	DOM.removeClass(DOM.children(songListUI,'li'),'nowPlaySong');
	DOM.addClass(songList[nowPlaySong.name],'nowPlaySong');
}
function showNtc(ntc,node,S){
	var DOM = S.DOM,Event = S.Event,
		span = DOM.children(node,'span')[0];
	span.innerHTML = ntc;
	DOM.show(node);
	setTimeout(function(){
		DOM.hide(node);
	},5000);
}
function showDownload(name,list,S){
	var DOM = S.DOM,Event = S.Event;
	var downloadBlock = DOM.get('#p-download'),
		content = DOM.children(downloadBlock,'.content')[0],
		ul = DOM.create('<ul></ul>');
	DOM.append(DOM.create('<li><h4>Download--'+name+'</h4></li>'),ul);
	for(var i=0;i<list.length;i++){
		DOM.append(DOM.create('<li><a href="'+list[i].url+'">'+list[i].url+'</a></li>'),ul);	
	}
	content.innerHTML = '';
	DOM.append(ul,content);
	DOM.show(downloadBlock);
}
KISSY.ready(function(S){
	var DOM = S.DOM,Event = S.Event;
	var tempntc = DOM.get('#tempntc');
	var playBlock = DOM.get('#play_block'),
		playBtn = DOM.get('#play_btn'),
		timerangeBtn = DOM.get('#timerange-btn'),
		songListUI = DOM.get('#showSongList'),
		timerange = DOM.get('#timerange'),
		timerangeTip = DOM.get('#timerange-tip');
	showSong(bg.songList._head,songListUI,S);
	showNowPlay(bg.nowPlaySong,songListUI,S);
	if(bg.songList._head.nxt.type == 'helpNode'){
		DOM.show('#p-firstntc');
	}
	document.body.scrollTop = 0;
	var prePauseedStat;
	if(prePauseedStat = audio.paused){
		DOM.addClass(playBtn,'pause');
	}else{
		DOM.addClass(playBtn,'play');
	}
	//========loop==============================================================================
	var loop = function(){
		//tempntc.innerHTML = parseInt(audio.currentTime/audio.duration*100);
		if(prePauseedStat != audio.paused){
			if(prePauseedStat = audio.paused){
				DOM.removeClass(playBtn,'play');
				DOM.addClass(playBtn,'pause');
			}else{
				DOM.removeClass(playBtn,'pause');
				DOM.addClass(playBtn,'play');
			}
		}
		var timernagWidth = (audio.currentTime/audio.duration)*DOM.width(timerange);
		if(!isNaN(timernagWidth)){
			timerangeBtn.style.width = timernagWidth + 'px';
			timerangeBtn.innerHTML = '';
		}else{
			if(audio.src != ''){
				timerangeBtn.style.width = '100%';
				timerangeBtn.innerHTML = 'Loading...';
			}else{
				timerangeBtn.style.width = '100%';
				timerangeBtn.innerHTML = 'Welcome to zMusic';
			}		
		}
		
	}
	loop();
	setInterval(function(){loop();},500);
	//==========form=============================================================
	Event.on('#form','submit',function(){
		DOM.hide('#form-help');
		var value = DOM.get('#form-text').value;
		bg.sendValue(value);
		return false;
	});
	//=========scroll for shadow dec========================================================
	Event.on(window,'scroll',function(){
		if(DOM.scrollTop(document)){
			if(!DOM.hasClass(playBlock,'play_block_shadow')){
				DOM.addClass(playBlock,'play_block_shadow');
			}
		}else{
			DOM.removeClass(playBlock,'play_block_shadow');
		}
	})
	//============play control========================================================
	Event.on('#play_btn','click',function(){
		//alert('center button');
		bg.centerBtnClick();
	});
	Event.on('#nxt_btn','click',function(){
		//alert('right button');
		bg.playNext();
	});
	Event.on('#pre_btn','click',function(){
		//alert('left button');
		bg.playPre();
	});
	Event.on('#timerange','click',function(e){
		var pst = (e.clientX - DOM.offset(this).left)/DOM.width(this);
		bg.timeRange(pst);
	})
	Event.on(timerange,'mouseenter',function(){
		DOM.show(timerangeTip);
	});
	Event.on(timerange,'mouseleave',function(){
		DOM.hide(timerangeTip);
	});
	Event.on(timerange,'mousemove',function(e){
		timerangeTip.style.left = e.clientX-20+'px';
		var value = (e.clientX - DOM.offset(timerange).left)/DOM.width(timerange);
		value = parseInt(value*audio.duration);
		DOM.children(timerangeTip,'span')[0].innerHTML = parseInt(value/60)+':'+(value%60);
	});
	//===========pop close=======================================================
	Event.on('.close','click',function(){
		DOM.hide(DOM.parent(this));
	});
	//============tag a to now tab===============================================
	Event.on(document,'click',function(e){
		if(e.target.tagName == 'a' || e.target.tagName == 'A' ){
			if(DOM.attr(e.target,'href')){
				chrome.tabs.create({url:DOM.attr(e.target,'href')});
			}
		}
	});
	//============form focus=====================================================
	Event.on('#form-text','focusin',function(){
		DOM.show('#form-help');
	});
	Event.on('#form-text','focusout',function(){
		DOM.hide('#form-help');
	});
	//==============setting pop==================================================
	Event.on('#p-setting-btn','click',function(){
		var settingPop = DOM.get('#p-setting'),
			autoPlay = DOM.get('#setting-autoplay .btnout'),
			notification = DOM.get('#setting-notification .btnout'),
			sound = DOM.get('#setting-soundvolume .btn');
		DOM.show(settingPop);
		if(parseInt(bg.localStorage.autoPlay)){
			DOM.removeClass(autoPlay,'btn-off');
			DOM.addClass(autoPlay,'btn-on');
		}else{
			DOM.removeClass(autoPlay,'btn-on');
			DOM.addClass(autoPlay,'btn-off');
		}
		if(parseInt(bg.localStorage.notification)){
			DOM.removeClass(notification,'btn-off');
			DOM.addClass(notification,'btn-on');
		}else{
			DOM.removeClass(notification,'btn-on');
			DOM.addClass(notification,'btn-off');
		}
		sound.style.width = (DOM.width(DOM.parent(sound))-2)*bg.audio.volume+'px';
		soundMoveTarget.innerHTML = parseInt(bg.audio.volume*100)+'%';
	});
	Event.on('#setting-autoplay .btnout','click',function(){
		bg.settings('autoplay',parseInt(bg.localStorage.autoPlay)?0:1);
		if(parseInt(bg.localStorage.autoPlay)){
			DOM.removeClass(this,'btn-off');
			DOM.addClass(this,'btn-on');
		}else{
			DOM.removeClass(this,'btn-on');
			DOM.addClass(this,'btn-off');
		}
	});
	Event.on('#setting-notification .btnout','click',function(){
		bg.settings('notification',parseInt(bg.localStorage.notification)?0:1);
		if(parseInt(bg.localStorage.notification)){
			DOM.removeClass(this,'btn-off');
			DOM.addClass(this,'btn-on');
		}else{
			DOM.removeClass(this,'btn-on');
			DOM.addClass(this,'btn-off');
		}
	});
	var soundMoveFlag = false;
	var soundMoveTarget = DOM.get('#setting-soundvolume .btn');
	Event.on(DOM.parent(soundMoveTarget),'mousedown',function(e){
		soundMoveFlag = true;
		var parent = DOM.parent(soundMoveTarget),
			parentWidth = DOM.width(parent)-2,
			length = e.clientX - DOM.offset(parent).left;
		if(length <= parentWidth && length>=0){
			soundMoveTarget.style.width = length+'px';
			soundMoveTarget.innerHTML = parseInt(length/parentWidth*100)+'%';
			//bg.audio.volume = length/parentWidth;
			bg.settings('sound',length/parentWidth);
		}
	});
	Event.on(document,'mousemove',function(e){
		if(soundMoveFlag){
			var parent = DOM.parent(soundMoveTarget),
				parentWidth = DOM.width(parent)-2,
				length = e.clientX - DOM.offset(parent).left;
			if(length <= parentWidth && length>=0){
				soundMoveTarget.style.width = length+'px';
				soundMoveTarget.innerHTML = parseInt(length/parentWidth*100)+'%';
				//bg.audio.volume = length/parentWidth;
				bg.settings('sound',length/parentWidth);
			}
		}
	});
	Event.on(document,'mouseup',function(){
		if(soundMoveFlag){			
			soundMoveFlag = false;
		}
	});
	Event.on('#about','click',function(){
		DOM.show('#p-firstntc');
		DOM.hide('#p-setting');
	});
	//=================RequestListener================================
	chrome.extension.onRequest.addListener(function(request,sender,sendResponse){
		for(i in request){
			switch(i){
				case 'ntc':
					showNtc(request.ntc,tempntc,S);
					break;
				case 'addSong':
					appendSong(request.addSong,songListUI,S);
					DOM.get('#form-text').value = '';
					break;
				case 'changePlay':
					showNowPlay(bg.nowPlaySong,songListUI,S);
					break;
			}
		}
	});
})
