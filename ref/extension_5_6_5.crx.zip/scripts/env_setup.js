var get_pref = function(key, callback)
{    
    chrome.extension.sendRequest({"msg_type": "get_pref", "key": key}, function(response)
    {
        if(callback) {
            callback(response.value);
        }
    });
};

var set_pref = function(key, value, callback)
{    
    chrome.extension.sendRequest({"msg_type": "set_pref", "key": key, "value": value}, function(response)
    {
        if(callback) {
            callback(response.status);
        }
    });
};

var setBoolPref = function(pref_name, value, callback)
{
    set_pref(pref_name, value, callback);
};

var getBoolPref = function(pref_name, callback)
{
    get_pref(pref_name, function(str)
    {
        if(callback) {
            callback((""+str) == "true");
        }
    });
};

var getStringPref = function(pref_name, callback)
{
    get_pref(pref_name, function(str)
    {
        if(callback) {
            callback(str);
        }
    });
};

var LOG_ERROR = function(){};
$.get = function(url, data, callback, type)
{
    chrome.extension.sendRequest({"msg_type": "$.get", "url": url, "data": data, "type": type}, function(response)
    {
        if(callback)
        {
            callback(response.data, response.textStatus);
        }
    });            
};

$.prototype.ready = function(callback) {
    callback();
};//doesn't work on Chrome, cheap hack
