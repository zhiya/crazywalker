//Note to editor: NOT executed from XUL
//Copyright 2009 Yongqian Li.

$(document).ready(function()
{
    if(!(self === top)) { //do not execute in iframe
        return;
    }
    
    var page_str = window.page_str || "Page";
    var loading_next_page_str = window.loading_next_page_str || "Loading next page...";

    
    
    var RETRY_FIND_NEXT_LINK = false; //to speed things up
    
    var scrolling_rules = [];
    getStringPref('install-source', function(install_source) {
    getStringPref('install-time', function(install_time) {
        $.get("http://api.smarterfox.com/api/infinite_scrolling_rules.json", 
        {
           locale: navigator.language || navigator.userLanguage,
           install_time: install_time,
           install_source: install_source        
        }, 
        function(data)
        {
            scrolling_rules = data;
        }, "json");
    });
    });
    
    var get_log_msg_url = function(msg)
    {
        msg['rand'] = parseInt(Math.random() * 1000000000);
        var params = [];
        for(var k in msg)
        {
            params.push(encodeURIComponent(k) + '=' + encodeURIComponent(msg[k]));
        }
        /*
        if('https:' == document.location.protocol)
        {
            return 'https://ssl.msgs.smarterfox.com/log_msg?' + params.join('&');
        }
        */
        return 'http://msgs.smarterfox.com/log_msg?' + params.join('&');
    };

    var check_scroll = function() 
    {
        getBoolPref("enable_endless_pages", function(pref_value)
        {
            if(pref_value && document.body)
            {
                var scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
                var scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
                var clientHeight = $(window).height(); //Math.min(document.documentElement.clientHeight, document.body.clientHeight);
                var remaining = scrollHeight - scrollTop - clientHeight;
                //alert(remaining);
                if(remaining < 300)
                {
                    setTimeout(function() {
                        load_next_page();
                    }, 0);
                }
            }
        });
    };
    
    $(window).scroll(check_scroll);
    setInterval(check_scroll, 400);//////////////////could lead to slow down?
    
    
    var identify_current_rule = function()
    {
        for(var i = 0; i < scrolling_rules.length; i++)
        {
            if(new RegExp(scrolling_rules[i]['url_matches']).test(window.location.href)) {
                return scrolling_rules[i];
            }
        }
        return null;
    };
    
    var $last_loaded_div = null;
    var $last_loaded_page = null;
    var identify_next_link = function(rule)
    {
        if(rule && rule['next_page_link_selector'])
        {
            var page = $last_loaded_page ? $last_loaded_page[0] : document;
            return $(page).find(rule['next_page_link_selector']);
        }
        else
        {
            return guess_next_page_link($last_loaded_page ? $last_loaded_page[0] : document);
        }
    };
    
    var is_invalid_page = function(rule)
    {
        if(!rule) {
            return guess_is_invalid_page();
        }
        else {
            return !rule['enabled'];
        }
    };
    
    var loading_next_page = false;
    var loaded_urls = {};
    var load_next_page = function()
    {
        var curr_rule = identify_current_rule();
        if(is_invalid_page(curr_rule) || loading_next_page) {
            return;
        }

        loading_next_page = true;

        var $next_link = identify_next_link(curr_rule);
        if($next_link && $next_link.length)
        {
            var url = $next_link[0].toString();
            
            if(!(url in loaded_urls))
            {
                loaded_urls[url] = null;

                $next_link.addClass("endless-pages-found-next-link");
                LOG_ERROR(url + ":" + $next_link.text());

                var loading_text = loading_next_page_str;
                $("body").append($('<div id="endless-pages-loading"><img id="endless-pages-loading-spinner" src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA%3D%3D" alt="spinner" />' + loading_text + '</div>').fadeIn());
                //url: http://static.smarterfox.com/media/smarterwiki/endless_pages/spinner.gif
                

                var insert_url = function(url)
                {
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function(data)
                        {
                            var redirect_url = get_meta_refresh(data);
                            if(redirect_url) {
                                insert_url(redirect_url);
                            }
                            else
                            {
                                insert_next_page(url, get_body_html(data), curr_rule);
                                $("#endless-pages-loading").fadeOut(function() {
                                    $(this).remove();
                                    loading_next_page = false;
                                });
                            }
                        }, 
                        error: function()
                        {
                            $("#endless-pages-loading").fadeOut(function() {
                                $(this).remove();
                                // loading_next_page = false; // don't try again
                            });
                        },
                        dataType: "html",
                        beforeSend: function(req)
                        {
                            req.setRequestHeader("X-moz", "prefetch");
                        }
                    });
                };
                insert_url(url);
            }
        }
        else {
            if(curr_rule || RETRY_FIND_NEXT_LINK) //always retry if we have rule since it's so fast
            {
                loading_next_page = false;
            }
        }
    };
    
    var num_pages_inserted = 0;
    var insert_next_page = function(url, body_html, curr_rule) //mimetype="text/xml"
    {        
        getStringPref('install-source', function(install_source) {
        getStringPref('install-time', function(install_time) {
            $.get(get_log_msg_url({name: 'next_page_inserted', 
                                   locale: navigator.language || navigator.userLanguage,
                                   install_time: install_time,
                                   install_source: install_source        
                                  }));
        });
        });

        
        var main_content_selector = curr_rule ? curr_rule['main_content_selector'] : null;
        var main_cnt = main_content_selector ? main_content_selector : "body";

        var $loaded_by_endless_pages = $("#loaded-by-endless-pages");
        if($loaded_by_endless_pages.length == 0)
        {
            $loaded_by_endless_pages = $('<div id="loaded-by-endless-pages"></div>');
            $loaded_by_endless_pages.css("margin-top", $(main_cnt).css("margin-bottom"))
                                    .css("padding-top", $(main_cnt).css("padding-bottom"));
            if(main_content_selector) {
                var $cnt = $(document).find(main_content_selector); //some sites (like reddit) produce invalid html with repeated ids, this is the workaround
                $loaded_by_endless_pages.appendTo($($cnt[$cnt.length - 1]));
            }
            else {
                $loaded_by_endless_pages.appendTo("body");
            }
        }

        num_pages_inserted += 1;
        var txt = page_str + " " + (num_pages_inserted + 1) + "";
        var break_style = main_content_selector ? 'endless-pages-page-break-auto' : 'endless-pages-page-break-full';
        var $page_break_div = $('<div class="' + break_style + '"><div class="endless-pages-page-break-desc">- <img class="smarterfox-icon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAgCAYAAADjaQM7AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAO/QAADv0BuNrVxAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAPdSURBVEiJxZZRaJtVFMd/9/tuEpM0Xbc1WVqw1bXaFSmjs4aKoBvFYqGDwYQJE7YHBV98+/RRwecP9EGGPglD2BDmULGOgi2DsKYPFWxFW+zaSqVOLXRZE9ukX77rw5evy5qbrC0OD1zIPf9zzv/cm3PO/YRSCgDLsqLAG8BZoBNIAoL9yV/AGPAdcMW27S0AoZTCsqzDQBo4ts/g9SQNnLZt+66Zy+Uk8A3w3CMgAmgDBkdHRz+TeFd3ykcGBgbo6uoiGo3uO/rq6iqzs7NMTEz4qhPAGQmc9DX9/f2kUql9k/iSTCZJJpMAlYSnJNDj77q7uwFw3AI3ly+zfO9nFF4BBYwQxxOD9MQHtoOO/+Hy/YqiWPJsBHCsyeB8p0HQgI6Ojiqyp/xdPB4HILNyjak731JZjAJYyc0Rj7STjHaysK745Be3qlyXci4RCeeOGrS2tlZCXQYQ8HemaQJwJz+PEAJQ28s/4Z/52wAsrHs+ascSAhbW1QPx/HwNNKJQlGPrMUDVwOu4oiV7VKIlkyK4fQIdBhA09LgCgjWOoFX3xAcQmkkVkY0cbeoDoPewoDFQZYIATrbo2aRO2XkwxcWej1jJzaFwPUMRpPNgisdkAwCNQcGH/SZTq4qi6yVmCHi6ER5v0I9ULRlAPNJOPNJeCwagISB4qWX3s1pLJrYU4S9/Q/66fr+0ggaFF49QeL552y6Yv04odxWlNjw/DJxQH5tN76BEaHdk4a+XCX/1e9UDE/hxjVJLL84TUWRxhujfb7LTSG6mQQTZaHq3Kq6+GufXve7c2bGAvO11s1n4oWxd1dbIwpQubL0+q9Wau8H12P/f1EqK2uNKev+RrgDKFjUxg4qwruv1VOGFhD5MVLLVewgAJ/IymAe0doXoq56N41SqtySwBDwJ3gubSCQo9jeTjR8vl345l6BJ8dlDuOWx4RrNZFtvEfjnBpRLHwxKoT6c0AkAstlsJdmSBH7yyRYXF0kkvFM5HTGcjpg28+2bMI9QiF3QYvl8nnQ6Xamal8At4DTA2NgYk5OTSFlzsBCLxRgaGqK5+X5zz8zMMD09TbFYpFQq4TgOa2trO10vS+AS8DrwjJ9RPclms2QyGYaHhwEYHx8nk8nU9QE+t237qmHb9j3gFeAakHuYl5+QUoqRkZF6RJvAKPAWcBHKH6m+WJZlAq2AqXEeBD4FaGtrIxwOMzc3V4nfAN4DiuW1ZNv2RqXBA2T1xLKsM8D1GvAV4IL/mV1L/osJ8jFw/mFEUOc926W8b9v2B7s13gvZ3YrfLvC2bduX9uC/p2u8CXyBN3Fe2ysRwL842lT1svaplQAAAABJRU5ErkJggg%3D%3D" /><a class="endless-pages-page-break-link" href="' + url + '">' + txt + '</a> -</div></div>')
                                    .appendTo($loaded_by_endless_pages);   
        //http://static.smarterfox.com/media/smarterwiki/smarterfox-logo.png                                            
                                    
        var parse_px = function(px_s)
        {
            var m = /(\d+)px/.exec(px_s);
            return (m && parseInt(m[1])) || 0;
        };
        $last_loaded_page = $('<div>' + body_html + '</div>');
        var $next_content = $(body_html);
        if(main_content_selector) {
            $next_content = $next_content.find(main_content_selector).children();
        }
        var $loaded_page_div = $('<div class="endless-pages-loaded-page' + (main_content_selector ? '-auto' : '-full') + '"></div>')
                                    .append($next_content)
                                    .appendTo($loaded_by_endless_pages);
        
        if(!main_content_selector) {
            $loaded_page_div.css("padding-top", 54 + parse_px($("body").css("margin-top")) + "px");
                //$loaded_page_div.css("margin-bottom", $("body").css("margin-bottom"));
        }
                
        if($last_loaded_div)
        {
            $last_loaded_div.css("margin-bottom", $(main_cnt).css("margin-bottom"))
                            .css("padding-bottom", $(main_cnt).css("padding-bottom")) //? should this be here?
                            .addClass("smarterwiki-clearfix");
        }
        $last_loaded_div = $loaded_page_div;
        /*
        var next_doc = new DOMParser().parseFromString(doc_str, mimetype);
        $(next_doc.body, next_doc).each(function()
        {
            if(this.nodeName != "script")
            {
                $next_page_div[0].appendChild(document.adoptNode(this));
            }
        });
        */
    };
});