(function()
{
    var get_log_msg_url = function(msg)
    {
        msg['rand'] = parseInt(Math.random() * 1000000000);
        var params = [];
        for(var k in msg)
        {
            params.push(encodeURIComponent(k) + '=' + encodeURIComponent(msg[k]));
        }
        /*
        if('https:' == document.location.protocol)
        {
            return 'https://ssl.msgs.smarterfox.com/log_msg?' + params.join('&');
        }
        */
        return 'http://msgs.smarterfox.com/log_msg?' + params.join('&');
    };
    
    var default_pref = {};
    var pref = function(key, value) {
        default_pref[key] = value;
    };   
    var read_pref = function(key)
    {
        var val = localStorage['pref.' + key];
        if(val == undefined) {
            val = default_pref[key];
        }
        return val;
    };
    var write_pref = function(key, val) {
        localStorage['pref.' + key] = val;
    };
    

    pref('install-time', '0');
    pref('install-source', '');
    pref('add_related_articles', true);
    pref('add_related_searches', true);
    pref('add_related_shopping_results', true);
    pref('add_price_comparison_results', true);    
    pref('add_related_search_results_oneriot', true);
    pref('add_trending_search_results_oneriot', true);
    pref('add_similar_product_search', true);
    pref('show_context_menu_additions', true);
    pref('show_popup_bubble', true);
    pref('search_wikipedia', true);
    pref('search_imdb', false);
    pref('search_duckduckgo', true);
    pref('search_yandex', false);
    pref('search_delicious', false);
    pref('search_surfcanyon', true);
    pref('search_twitter', false);
    pref('tweet_this', false);
    pref('search_bing', false);
    pref('search_baidu', false);
    pref('search_reddit', false);
    pref('search_youtube', false);
    pref('search_wiktionary', false);
    pref('search_google', true);
    pref('popup_bubble_show_definitions', true);
    pref('popup_bubble_show_link_info', false);
    pref('popup_bubble_add_share_attribution', true);
    pref('popup_bubble_show_link_info_always', false);
    pref('popup_bubble_open_new_tab', true);
    pref('popup_bubble_force_single_row', false);
    pref('enhance_urlbar', true);
    pref('num_urlbar_from_history', 4);
    pref('enable_qlauncher', true);
    pref('qlauncher_invoke_key', 'CTRL+SPACE');
    pref('qlauncher_open_new_tab', true);
    pref('enable_linkify', true);
    pref('enable_endless_pages', true);
    pref('auto_copy_selected', false);
    pref('enable_middle_click_paste', false);
    pref('enable_right_click_paste', false);
    pref('insert_aff_code', true);
    pref('add_search_refinements', true);
    pref('last-version', 'firstrun');
    
    if(!read_pref('install-source')) {
        write_pref('install-source', 'Chrome Webstore');
    }


    chrome.extension.onRequest.addListener(function(request, sender, sendResponse)
    {
        if(request.msg_type == 'get_localStorage')
        {
            sendResponse({'value': localStorage[request.key]});
        }
        else if(request.msg_type == 'get_pref')
        {
            sendResponse({'value': read_pref(request.key)});
        }
        else if(request.msg_type == 'show_options')
        {
            var url = chrome.extension.getURL('options.html');
            chrome.tabs.create({
                index: 100000000, //last
                url: url
            });
            sendResponse({});
        }
        else if(request.msg_type == 'set_pref')
        {
            write_pref(request.key, request.value);
            sendResponse({'status': true});
        }
        else if(request.msg_type == '$.get')
        {
            $.get(request.url, request.data, function(data, textStatus)
            {
                sendResponse({'data': data, 'textStatus': textStatus});
            }, request.type);
        }
        else
        {
            invisiblehand.handleExtensionRequest(request, sender, sendResponse);        
            //sendResponse({});
        }
    });
    
    //set up context menu
    chrome.contextMenus.create({
        title: 'Add scrolling rule...',
        onclick: function(info, tab) {
            chrome.tabs.executeScript(tab.id, {
                code: 'activate_rule_creator()'
            })
        }
    });

    
    
    var onuninstallURL = function(install_time, install_duration) {
        return 'http://smarterfox.com/smarterwiki/uninstalled/?install_time=' + install_time + '&install_duration=' + install_duration;
    };
    var ondisableURL = function(install_time, install_duration) {
        return 'http://smarterfox.com/smarterwiki/disabled/?install_time=' + install_time + '&install_duration=' + install_duration;
    };
    var oninstallURL = function(lastVersion, currentVersion) {
        return 'http://smarterfox.com/smarterwiki/installed/?from_ver=' + lastVersion + '&to_ver=' + currentVersion;
    };
    var onupdateURL = function(lastVersion, currentVersion) {
        return 'http://smarterfox.com/smarterwiki/updated/?from_ver=' + lastVersion + '&to_ver=' + currentVersion;
    };
    
    
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if(xhr.readyState==4)
        {
            var data = JSON.parse(xhr.responseText);
            var current_version = data.version;
            if(read_pref('last-version') != current_version)
            {
                if(read_pref('last-version') == 'firstrun')
                {
                    write_pref('install-time', new Date().getTime());
                    $.get(get_log_msg_url({name: 'FastestChrome_installed', 
                                           version_from: read_pref('last-version'),
                                           version_to: current_version, 
                                           locale: navigator.language,
                                           install_time: read_pref('install-time'),
                                           install_source: read_pref('install-source')
                                          }));
                }
                else
                {
                    //was updated
                    if(read_pref('last-version').indexOf('3') == 0)
                    {
                        chrome.tabs.create({
                            index: 100000000, //last
                            url: onupdateURL(read_pref('last-version'), current_version)
                        });
                    }

                    $.get(get_log_msg_url({name: 'FastestChrome_updated', 
                                           version_from: read_pref('last-version'),
                                           version_to: current_version, 
                                           locale: navigator.language,
                                           shopping_pref: read_pref('add_related_shopping_results'),
                                           superfish_pref: read_pref('add_similar_product_search'),
                                           refinements_pref: read_pref('add_search_refinements'),
                                           link_info_pref: read_pref('popup_bubble_show_link_info'),
                                           install_time: read_pref('install-time'),
                                           install_source: read_pref('install-source')
                                          }));

                    if(current_version == '5.1.5')
                    {
                        write_pref('popup_bubble_show_link_info') = false;
                    }
                }

                if(read_pref('last-version') == 'firstrun')
                {
                    chrome.tabs.create({
                        index: 100000000, //last
                        url: oninstallURL(read_pref('last-version'), current_version)
                    });
                } //only open new page if first install

                write_pref('last-version', current_version);
            }
        }
    };
    xhr.open('GET', chrome.extension.getURL('manifest.json'), true);
    xhr.send();
}());