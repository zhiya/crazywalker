(function()
{
    var get_pref = function(key, callback)
    {    
        chrome.extension.sendRequest({"msg_type": "get_pref", "key": key}, function(response)
        {
            if(callback) {
                callback(response.value);
            }
        });
    };

    var set_pref = function(key, value, callback)
    {    
        chrome.extension.sendRequest({"msg_type": "set_pref", "key": key, "value": value}, function(response)
        {
            if(callback) {
                callback(response.status);
            }
        });
    };

    var setBoolPref = function(pref_name, value, callback)
    {
        set_pref(pref_name, value, callback);
    };

    var getBoolPref = function(pref_name, callback)
    {
        get_pref(pref_name, function(str)
        {
            if(callback) {
                callback((""+str) == "true");
            }
        });
    };

    

    $(document).ready(function()
    {
        var link_checkbox_to_pref = function($checkbox, pref_key)
        {
            var recv_value = function()
            {
                getBoolPref(pref_key, function(val)
                {
                    $checkbox.attr("checked", val);
                });
            };
            var send_value = function()
            {
                setBoolPref(pref_key, $checkbox.attr("checked"));
            };
            
            
            recv_value();
            $checkbox.click(send_value).change(send_value);
        };
        
        link_checkbox_to_pref($("#enable-linkify-checkbox"), "enable_linkify");
        link_checkbox_to_pref($("#add-related-articles-checkbox"), "add_related_articles");
        link_checkbox_to_pref($("#enable-endless-pages-checkbox"), "enable_endless_pages");
        link_checkbox_to_pref($("#add-related-searches-checkbox"), "add_related_searches");
        link_checkbox_to_pref($("#add-related-shopping-results-checkbox"), "add_related_shopping_results");
        link_checkbox_to_pref($("#add-price-comparison-results-checkbox"), "add_price_comparison_results");
        link_checkbox_to_pref($("#add-search-refinements-checkbox"), "add_search_refinements");
        link_checkbox_to_pref($("#add-similar-product-search-checkbox"), "add_similar_product_search");
        link_checkbox_to_pref($("#show-popup-bubble-checkbox"), "show_popup_bubble");
        link_checkbox_to_pref($("#search-wikipedia-checkbox"), "search_wikipedia");
        link_checkbox_to_pref($("#search-imdb-checkbox"), "search_imdb");
        link_checkbox_to_pref($("#search-duckduckgo-checkbox"), "search_duckduckgo");
        link_checkbox_to_pref($("#search-yandex-checkbox"), "search_yandex");
        link_checkbox_to_pref($("#search-delicious-checkbox"), "search_delicious");
        link_checkbox_to_pref($("#search-twitter-checkbox"), "search_twitter");
        link_checkbox_to_pref($("#search-surfcanyon-checkbox"), "search_surfcanyon");
        link_checkbox_to_pref($("#search-bing-checkbox"), "search_bing");
        link_checkbox_to_pref($("#search-baidu-checkbox"), "search_baidu");
        link_checkbox_to_pref($("#search-youtube-checkbox"), "search_youtube");
        link_checkbox_to_pref($("#search-wiktionary-checkbox"), "search_wiktionary");
        link_checkbox_to_pref($("#search-google-checkbox"), "search_google");
        
        link_checkbox_to_pref($("#popup-bubble-show-definitions-checkbox"), "popup_bubble_show_definitions");
        link_checkbox_to_pref($("#popup-bubble-show-link-info-checkbox"), "popup_bubble_show_link_info");
        link_checkbox_to_pref($("#popup-bubble-add-share-attribution-checkbox"), "popup_bubble_add_share_attribution");        
        link_checkbox_to_pref($("#popup-bubble-show-link-info-always-checkbox"), "popup_bubble_show_link_info_always");
        link_checkbox_to_pref($("#popup-bubble-open-new-tab-checkbox"), "popup_bubble_open_new_tab");
        link_checkbox_to_pref($("#popup-bubble-force-single-row-checkbox"), "popup_bubble_force_single_row");
    });
}());